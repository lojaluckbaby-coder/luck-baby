export async function onRequestGet({params,env}){
  if(!env.BUCKET) return new Response('R2 não configurado',{status:503});
  const key=decodeURIComponent(params.key||''); const obj=await env.BUCKET.get(key);
  if(!obj) return new Response('Imagem não encontrada',{status:404});
  const headers=new Headers(); obj.writeHttpMetadata(headers); headers.set('etag',obj.httpEtag); headers.set('Cache-Control','public,max-age=31536000,immutable');
  return new Response(obj.body,{headers});
}
